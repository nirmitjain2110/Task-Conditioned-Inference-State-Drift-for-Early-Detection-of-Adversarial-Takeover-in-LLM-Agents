import torch
import numpy as np
import pandas as pd
from typing import List, Dict, Any

class HiddenStateMonitor:
    """
    Computes trajectory signals from consecutive hidden state representations.
    """
    def __init__(self):
        pass

    @staticmethod
    def compute_trajectory_metrics(hidden_states: List[torch.Tensor], entropies: List[float], tokens: List[str]) -> List[Dict[str, Any]]:
        """
        Takes a list of 1D hidden state Tensors [h_0, h_1, ..., h_T] and returns a list of step dictionaries.
        """
        trajectory_records = []
        num_steps = len(hidden_states)
        
        for t in range(num_steps):
            h_t = hidden_states[t]
            entropy_t = entropies[t]
            token_t = tokens[t] if t < len(tokens) else ""
            
            if t == 0:
                displacement = 0.0
                directional_drift = 0.0
                entropy_delta = 0.0
            else:
                h_prev = hidden_states[t - 1]
                entropy_prev = entropies[t - 1]
                
                # 1. Displacement (Euclidean Norm)
                diff = h_t - h_prev
                displacement = torch.linalg.vector_norm(diff).item()
                
                # 2. Directional Drift (1 - Cosine Similarity)
                cos_sim = torch.nn.functional.cosine_similarity(
                    h_t.unsqueeze(0),
                    h_prev.unsqueeze(0)
                ).item()
                directional_drift = max(0.0, 1.0 - cos_sim)
                
                # 3. Entropy Delta
                entropy_delta = abs(entropy_t - entropy_prev)
                
            record = {
                "step": t,
                "token": token_t,
                "displacement": displacement,
                "directional_drift": directional_drift,
                "entropy": entropy_t,
                "entropy_delta": entropy_delta,
                "hidden_state_vector": h_t.numpy()
            }
            trajectory_records.append(record)
            
        return trajectory_records

    @staticmethod
    def trajectory_to_dataframe(trajectory_records: List[Dict[str, Any]], run_id: str, is_attack: bool) -> pd.DataFrame:
        """
        Converts trajectory records to a Pandas DataFrame for analysis/saving.
        """
        rows = []
        for rec in trajectory_records:
            rows.append({
                "run_id": run_id,
                "is_attack": is_attack,
                "step": rec["step"],
                "token": rec["token"],
                "displacement": rec["displacement"],
                "directional_drift": rec["directional_drift"],
                "entropy": rec["entropy"],
                "entropy_delta": rec["entropy_delta"]
            })
        return pd.DataFrame(rows)
