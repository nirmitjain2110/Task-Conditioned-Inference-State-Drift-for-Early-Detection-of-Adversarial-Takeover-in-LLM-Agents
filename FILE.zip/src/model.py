import sys
sys.modules["tensorflow"] = None

import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import torch
import numpy as np
from typing import Tuple, Dict, Any, List, Optional
from transformers import AutoTokenizer, AutoModelForCausalLM

class LocalAgentModel:
    """
    Wrapper around local instruction-tuned causal LLM to expose internal hidden states
    and output distributions during inference.
    """
    def __init__(self, model_id: str = "Qwen/Qwen2.5-1.5B-Instruct", layer_index: Optional[int] = None, device: Optional[str] = None):
        self.model_id = model_id
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
            
        print(f"[Model Loader] Loading model '{self.model_id}' on device '{self.device}'...")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        
        # Load model with auto dtype
        torch_dtype = torch.float16 if self.device == "cuda" else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_id,
            torch_dtype=torch_dtype,
            device_map="auto" if self.device == "cuda" else None
        )
        if self.device != "cuda":
            self.model.to(self.device)
            
        self.model.eval()
        
        # Determine number of layers & set target hidden layer
        self.num_layers = self.model.config.num_hidden_layers
        self.hidden_size = self.model.config.hidden_size
        
        if layer_index is None:
            # Default to ~75% depth of the network (e.g., layer 21 for 28 layers)
            self.target_layer = int(self.num_layers * 0.75)
        else:
            self.target_layer = min(layer_index, self.num_layers - 1)
            
        print(f"[Model Loader] Successfully loaded! Num Layers: {self.num_layers}, Hidden Size: {self.hidden_size}, Target Layer for Monitoring: {self.target_layer}")

    def get_hidden_state_and_logits(self, prompt: str) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Runs a single forward pass over prompt text and returns:
        - last token hidden state at `target_layer` (shape: [hidden_size])
        - last token logits (shape: [vocab_size])
        """
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        with torch.no_grad():
            outputs = self.model(
                **inputs,
                output_hidden_states=True,
                use_cache=True
            )
        
        # outputs.hidden_states is a tuple of (embeddings, layer_1, layer_2, ..., layer_L)
        # target_layer index + 1 corresponds to layer output (+1 for embedding)
        hidden_layer_tensor = outputs.hidden_states[self.target_layer + 1] # shape [batch, seq_len, hidden_size]
        last_hidden_state = hidden_layer_tensor[0, -1, :].detach().float().cpu()
        last_logits = outputs.logits[0, -1, :].detach().float().cpu()
        
        return last_hidden_state, last_logits

    def generate_with_state_tracking(self, prompt_text: str, max_new_tokens: int = 40) -> Dict[str, Any]:
        """
        Generates text token-by-token, extracting the hidden state vector and token entropy at each step t.
        """
        input_ids = self.tokenizer(prompt_text, return_tensors="pt").input_ids.to(self.device)
        
        generated_tokens = []
        hidden_states_trajectory = []
        entropies_trajectory = []
        
        current_input_ids = input_ids.clone()
        
        for step in range(max_new_tokens):
            with torch.no_grad():
                outputs = self.model(
                    current_input_ids,
                    output_hidden_states=True,
                    use_cache=True
                )
                
            # Extract last token hidden state at target layer
            hidden_tensor = outputs.hidden_states[self.target_layer + 1]
            last_h = hidden_tensor[0, -1, :].detach().float().cpu()
            
            # Extract last token logits and calculate entropy
            logits = outputs.logits[0, -1, :].detach().float().cpu()
            probs = torch.softmax(logits, dim=-1)
            entropy = -torch.sum(probs * torch.log(probs + 1e-9)).item()
            
            # Greedy next token selection
            next_token_id = torch.argmax(logits, dim=-1, keepdim=True).unsqueeze(0).to(self.device)
            token_str = self.tokenizer.decode(next_token_id[0])
            
            generated_tokens.append(token_str)
            hidden_states_trajectory.append(last_h)
            entropies_trajectory.append(entropy)
            
            # Append token to sequence
            current_input_ids = torch.cat([current_input_ids, next_token_id], dim=1)
            
            # Stop if EOS token
            if next_token_id.item() == self.tokenizer.eos_token_id:
                break
                
        full_generated_text = self.tokenizer.decode(current_input_ids[0], skip_special_tokens=True)
        
        return {
            "generated_text": full_generated_text,
            "generated_tokens": generated_tokens,
            "hidden_states": hidden_states_trajectory, # list of 1D Tensors
            "entropies": entropies_trajectory
        }
