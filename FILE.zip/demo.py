import sys
sys.modules["tensorflow"] = None

import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import time
import pandas as pd
import numpy as np

from src.model import LocalAgentModel
from src.tasks import BENIGN_INVOICES, format_agent_prompt
from src.attacks import ADVERSARIAL_INVOICES
from src.monitor import HiddenStateMonitor

def print_header(title: str):
    print("\n" + "=" * 65)
    print(f"  {title}")
    print("=" * 65 + "\n")

def run_live_demo(model_id: str = "Qwen/Qwen2.5-0.5B-Instruct"):
    print_header("DEMO: Task-Conditioned Inference-State Drift Monitor")
    
    print("SYSTEM ARCHITECTURE:")
    print("  [LLM Model] : Qwen2.5 (Local HuggingFace Causal Transformer)")
    print("  [Monitor]   : Hidden-State Layer 18 Activation Vector Extractor")
    print("  [Metric]    : Step-by-Step Euclidean Displacement D_t = ||h_t - h_{t-1}||_2")
    print("-" * 65)

    input("\n--> Press ENTER to initialize local LLM and start DEMO STEP 1 (Benign Task)...")

    # Initialize model & monitor
    agent_model = LocalAgentModel(model_id=model_id)
    monitor = HiddenStateMonitor()

    # -------------------------------------------------------------
    # STEP 1: Benign Invoice Processing
    # -------------------------------------------------------------
    print_header("STEP 1: Executing Legitimate / Benign Invoice Task")
    benign_doc = BENIGN_INVOICES[0]["content"]
    print("DOCUMENT CONTENT:")
    print(f"  \"{benign_doc.replace(chr(10), ' ')}\"\n")
    
    prompt = format_agent_prompt("invoice_summary", benign_doc)
    print("Generating LLM Response & Measuring Hidden-State Displacement Live...")
    print("-" * 60)
    print(f"{'Step':<6} | {'Token Generated':<18} | {'Displacement ||h_t - h_{t-1}||':<30}")
    print("-" * 60)

    res_normal = agent_model.generate_with_state_tracking(prompt, max_new_tokens=15)
    recs_normal = monitor.compute_trajectory_metrics(res_normal["hidden_states"], res_normal["entropies"], res_normal["generated_tokens"])

    for r in recs_normal:
        print(f"t={r['step']:<4} | {repr(r['token']):<18} | D_t = {r['displacement']:<8.4f}")
        time.sleep(0.08) # Smooth terminal animation effect

    print("-" * 60)
    print(f"Benign Execution Complete. Average Displacement: {np.mean([r['displacement'] for r in recs_normal[1:]]):.4f}\n")

    input("--> Press ENTER to start DEMO STEP 2 (Adversarial Prompt Injection Task)...")

    # -------------------------------------------------------------
    # STEP 2: Adversarial Invoice Processing
    # -------------------------------------------------------------
    print_header("STEP 2: Executing Adversarial Indirect Prompt-Injection Task")
    attack_doc = ADVERSARIAL_INVOICES[0]["content"]
    print("DOCUMENT CONTENT (Contains Indirect Injection Payload):")
    print(f"  \"{attack_doc.replace(chr(10), ' ')}\"\n")
    
    prompt_attack = format_agent_prompt("invoice_summary", attack_doc)
    print("Generating LLM Response & Measuring Hidden-State Displacement Live...")
    print("-" * 60)
    print(f"{'Step':<6} | {'Token Generated':<18} | {'Displacement ||h_t - h_{t-1}||':<30}")
    print("-" * 60)

    res_attack = agent_model.generate_with_state_tracking(prompt_attack, max_new_tokens=15)
    recs_attack = monitor.compute_trajectory_metrics(res_attack["hidden_states"], res_attack["entropies"], res_attack["generated_tokens"])

    for r in recs_attack:
        disp = r['displacement']
        # Highlight anomalous displacement spikes
        if disp > 25.0:
            status = f"D_t = {disp:<8.4f}  <-- [INFERENCE DRIFT SPIKE DETECTED]"
        else:
            status = f"D_t = {disp:<8.4f}"
        print(f"t={r['step']:<4} | {repr(r['token']):<18} | {status}")
        time.sleep(0.08)

    print("-" * 60)
    print(f"Adversarial Execution Complete. Average Displacement: {np.mean([r['displacement'] for r in recs_attack[1:]]):.4f}\n")

    # -------------------------------------------------------------
    # STEP 3: Display Summary Comparison & Visual Graph
    # -------------------------------------------------------------
    print_header("STEP 3: Trajectory Comparison Summary")
    print("\n[Opening Visual Trajectory Graph: 'trajectory_plot.png'...]")
    
    # Auto-generate & pop open the plot image
    os.system("python scripts/02_visualize.py")
    if sys.platform == "win32":
        os.system("start trajectory_plot.png")
    
    print("\n==================================================")
    print("  DEMO COMPLETE! [OK]")
    print("==================================================\n")

if __name__ == "__main__":
    run_live_demo()
