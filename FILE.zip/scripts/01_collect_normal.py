import sys
sys.modules["tensorflow"] = None

import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
import argparse
import numpy as np
import pandas as pd
from typing import List

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.model import LocalAgentModel
from src.tasks import BENIGN_INVOICES, format_agent_prompt
from src.monitor import HiddenStateMonitor

def main():
    parser = argparse.ArgumentParser(description="Stage 2: Collect Normal LLM Agent Trajectories")
    parser.add_argument("--model_id", type=str, default="Qwen/Qwen2.5-0.5B-Instruct", help="Hugging Face model ID")
    parser.add_argument("--max_tokens", type=int, default=30, help="Number of tokens to generate per trajectory")
    parser.add_argument("--layer_index", type=int, default=None, help="Target transformer layer index")
    args = parser.parse_args()

    os.makedirs("data/normal", exist_ok=True)

    print("==================================================")
    print("Stage 2 — Normal Trajectory Collection Pipeline")
    print(f"Model ID: {args.model_id}")
    print(f"Max Generation Tokens: {args.max_tokens}")
    print("==================================================")

    # Initialize agent model & monitor
    agent_model = LocalAgentModel(model_id=args.model_id, layer_index=args.layer_index)
    monitor = HiddenStateMonitor()

    normal_dfs = []

    print(f"\nProcessing {len(BENIGN_INVOICES)} benign task scenarios...")
    for idx, inv in enumerate(BENIGN_INVOICES):
        run_id = f"normal_{inv['id']}"
        prompt = format_agent_prompt("invoice_summary", inv["content"])
        
        print(f"\n[Run {idx+1}/{len(BENIGN_INVOICES)}] {run_id}...")
        gen_res = agent_model.generate_with_state_tracking(prompt, max_new_tokens=args.max_tokens)
        
        # Calculate step metrics
        records = monitor.compute_trajectory_metrics(gen_res["hidden_states"], gen_res["entropies"], gen_res["generated_tokens"])
        df = monitor.trajectory_to_dataframe(records, run_id=run_id, is_attack=False)
        
        # Save trajectory records and raw hidden vector matrices
        csv_path = f"data/normal/{run_id}.csv"
        npy_path = f"data/normal/{run_id}_vectors.npy"
        
        df.to_csv(csv_path, index=False)
        vectors = np.array([r["hidden_state_vector"] for r in records])
        np.save(npy_path, vectors)
        
        normal_dfs.append(df)
        print(f"  [OK] Tokens generated: {len(gen_res['generated_tokens'])}")
        print(f"  [OK] Saved state vectors: {vectors.shape}")
        print(f"  [OK] Text snippet: {gen_res['generated_text'][:60]}...")

    # Save combined normal dataset
    combined_df = pd.concat(normal_dfs, ignore_index=True)
    summary_path = "data/normal_features.csv"
    combined_df.to_csv(summary_path, index=False)

    print("\n==================================================")
    print("Stage 2 — Normal Trajectory Collection Complete! [OK]")
    print(f"Total steps logged across all normal runs: {len(combined_df)}")
    print(f"Summary saved to: '{summary_path}'")
    print(f"Vector matrices saved in: 'data/normal/*.npy'")
    print("==================================================")

if __name__ == "__main__":
    main()
