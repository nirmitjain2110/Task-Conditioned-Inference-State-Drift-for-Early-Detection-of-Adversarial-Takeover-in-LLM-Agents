import sys
sys.modules["tensorflow"] = None

import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import argparse
import numpy as np
import pandas as pd
from typing import List

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.model import LocalAgentModel
from src.tasks import format_agent_prompt
from src.attacks import ADVERSARIAL_INVOICES
from src.monitor import HiddenStateMonitor

def main():
    parser = argparse.ArgumentParser(description="Stage 3: Collect Adversarial LLM Agent Trajectories")
    parser.add_argument("--model_id", type=str, default="Qwen/Qwen2.5-0.5B-Instruct", help="Hugging Face model ID")
    parser.add_argument("--max_tokens", type=int, default=30, help="Number of tokens to generate per trajectory")
    parser.add_argument("--layer_index", type=int, default=None, help="Target transformer layer index")
    args = parser.parse_args()

    os.makedirs("data/attacks", exist_ok=True)

    print("==================================================")
    print("Stage 3 — Adversarial Trajectory Collection Pipeline")
    print(f"Model ID: {args.model_id}")
    print(f"Max Generation Tokens: {args.max_tokens}")
    print("==================================================")

    # Initialize agent model & monitor
    agent_model = LocalAgentModel(model_id=args.model_id, layer_index=args.layer_index)
    monitor = HiddenStateMonitor()

    attack_dfs = []

    print(f"\nProcessing {len(ADVERSARIAL_INVOICES)} indirect prompt-injection attack scenarios...")
    for idx, inv in enumerate(ADVERSARIAL_INVOICES):
        run_id = f"attack_{inv['id']}"
        prompt = format_agent_prompt("invoice_summary", inv["content"])
        
        print(f"\n[Attack Run {idx+1}/{len(ADVERSARIAL_INVOICES)}] {run_id}...")
        gen_res = agent_model.generate_with_state_tracking(prompt, max_new_tokens=args.max_tokens)
        
        # Calculate step metrics
        records = monitor.compute_trajectory_metrics(gen_res["hidden_states"], gen_res["entropies"], gen_res["generated_tokens"])
        df = monitor.trajectory_to_dataframe(records, run_id=run_id, is_attack=True)
        
        # Save trajectory records and raw hidden vector matrices
        csv_path = f"data/attacks/{run_id}.csv"
        npy_path = f"data/attacks/{run_id}_vectors.npy"
        
        df.to_csv(csv_path, index=False)
        vectors = np.array([r["hidden_state_vector"] for r in records])
        np.save(npy_path, vectors)
        
        attack_dfs.append(df)
        print(f"  [OK] Tokens generated: {len(gen_res['generated_tokens'])}")
        print(f"  [OK] Saved state vectors: {vectors.shape}")
        print(f"  [OK] Text snippet: {gen_res['generated_text'][:60]}...")

    # Combine with normal dataset if available
    normal_summary_path = "data/normal_features.csv"
    if os.path.exists(normal_summary_path):
        normal_df = pd.read_csv(normal_summary_path)
        combined_df = pd.concat([normal_df] + attack_dfs, ignore_index=True)
    else:
        combined_df = pd.concat(attack_dfs, ignore_index=True)

    summary_path = "data/features.csv"
    combined_df.to_csv(summary_path, index=False)

    print("\n==================================================")
    print("Stage 3 — Adversarial Trajectory Collection Complete! [OK]")
    print(f"Total steps logged across adversarial runs: {sum(len(d) for d in attack_dfs)}")
    print(f"Combined features saved to: '{summary_path}'")
    print(f"Vector matrices saved in: 'data/attacks/*.npy'")
    print("==================================================")

if __name__ == "__main__":
    main()
