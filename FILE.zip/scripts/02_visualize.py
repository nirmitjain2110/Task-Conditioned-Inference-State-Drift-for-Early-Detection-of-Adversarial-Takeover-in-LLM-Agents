import sys
sys.modules["tensorflow"] = None

import os
os.environ["USE_TF"] = "0"
os.environ["USE_TORCH"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    print("==================================================")
    print("Generating Hidden State Displacement Trajectory Plot")
    print("==================================================")

    # Set visual theme
    sns.set_theme(style="darkgrid")
    plt.rcParams.update({'font.size': 12})

    features_path = "data/features.csv"
    if not os.path.exists(features_path):
        print(f"Error: {features_path} not found. Please run collection scripts first!")
        return

    df = pd.read_csv(features_path)

    # Create single clean figure for Hidden State Displacement
    fig, ax = plt.subplots(figsize=(10, 6))

    normal_color = "#1f77b4"  # Deep Blue
    attack_color = "#d62728"  # Vivid Red

    # Plot Normal Executions curve
    sns.lineplot(
        data=df[~df['is_attack']],
        x='step', y='displacement',
        ax=ax, color=normal_color, label='Normal Executions (Benign)', linewidth=3.0, errorbar='sd'
    )

    # Plot Adversarial Injections curve
    sns.lineplot(
        data=df[df['is_attack']],
        x='step', y='displacement',
        ax=ax, color=attack_color, label='Adversarial Injections (Prompt Injection)', linewidth=3.0, errorbar='sd'
    )

    ax.set_title("Inference-State Drift: Hidden State Displacement (||h_t - h_{t-1}||_2)", fontsize=14, fontweight='bold', pad=15)
    ax.set_xlabel("Inference / Token Step (t)", fontsize=12, fontweight='bold')
    ax.set_ylabel("Euclidean Displacement Norm", fontsize=12, fontweight='bold')
    ax.legend(loc='upper right', fontsize=11, frameon=True)

    plt.tight_layout()
    output_img = "trajectory_plot.png"
    plt.savefig(output_img, dpi=300, bbox_inches='tight')
    print(f"\n[Success] Single displacement plot saved successfully to '[trajectory_plot.png](file:///{os.path.abspath(output_img)})'!")

if __name__ == "__main__":
    main()
